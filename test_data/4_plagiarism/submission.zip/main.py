def find_largest_palindrome(text):
    """Find the largest palindrome substring in given text"""
    if not text:
        return ""

    max_pal = ""  # Renamed variable
    n = len(text)

    # Check all substrings
    for i in range(n):
        for j in range(i + 1, n + 1):
            substr = text[i:j]  # Renamed variable
            if substr == substr[::-1]:  # Same logic, different var names
                if len(substr) > len(max_pal):
                    max_pal = substr

    return max_pal

def is_palindrome(s):
    """Check if string is palindrome"""
    return s == s[::-1]

def main():
    test_string = "babad"
    result = find_largest_palindrome(test_string)
    print(f"Largest palindrome in '{test_string}': '{result}'")

# Additional function copied from elsewhere
def utility_function(x, y):
    """Utility function that appears to be copied"""
    return (x + y) * 2
