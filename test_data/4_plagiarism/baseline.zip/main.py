def find_largest_palindrome(text):
    """Find the largest palindrome substring in given text"""
    if not text:
        return ""

    max_palindrome = ""
    n = len(text)

    # Check all substrings
    for i in range(n):
        for j in range(i + 1, n + 1):
            substring = text[i:j]
            if substring == substring[::-1]:  # Palindrome check
                if len(substring) > len(max_palindrome):
                    max_palindrome = substring

    return max_palindrome

def is_palindrome(s):
    """Check if string is palindrome"""
    return s == s[::-1]

def main():
    test_string = "babad"
    result = find_largest_palindrome(test_string)
    print(f"Largest palindrome in '{test_string}': '{result}'")

if __name__ == "__main__":
    main()
