# ===== TEMPLATE SECTION START =====
# This section contains boilerplate/template code that should be ignored
# during code DNA analysis as it represents standard project scaffolding

PROJECT_NAME = "MyAwesomeProject"
VERSION = "1.0.0"
AUTHOR = "Developer Name"
CREATED_DATE = "2023-01-01"

def setup_logging():
    """Template function for setting up logging - should be subtracted"""
    import logging
    logging.basicConfig(level=logging.INFO)
    return logging.getLogger(__name__)

def load_config():
    """Template function for loading configuration - should be subtracted"""
    config = {
        "debug": False,
        "port": 8080,
        "host": "localhost"
    }
    return config

# ===== TEMPLATE SECTION END =====

# ===== ACTUAL STUDENT WORK BEGINS HERE =====

def calculate_factorial(n):
    """
    Calculate factorial of a number using recursion.
    This is the actual algorithmic work submitted by the student.
    """
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers")
    if n == 0 or n == 1:
        return 1
    return n * calculate_factorial(n - 1)

def is_prime(number):
    """
    Check if a number is prime.
    Another example of student's original work.
    """
    if number < 2:
        return False
    if number == 2:
        return True
    if number % 2 == 0:
        return False
    for i in range(3, int(number**0.5) + 1, 2):
        if number % i == 0:
            return False
    return True

def process_mathematical_operations(numbers):
    """
    Process a list of numbers through various mathematical operations.
    Demonstrates student's understanding of algorithms and functions.
    """
    results = {
        'factorials': [],
        'primes': [],
        'evens': [],
        'odds': []
    }

    for num in numbers:
        # Calculate factorial (for small numbers to avoid overflow)
        if 0 <= num <= 10:  # Limit to prevent excessive computation
            try:
                fact = calculate_factorial(num)
                results['factorials'].append(fact)
            except ValueError:
                results['factorials'].append(None)

        # Check if prime
        if is_prime(num):
            results['primes'].append(num)

        # Categorize even/odd
        if num % 2 == 0:
            results['evens'].append(num)
        else:
            results['odds'].append(num)

    return results

def main():
    """Main function demonstrating the student's work"""
    # Test data for mathematical operations
    test_numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    # Process the numbers
    results = process_mathematical_operations(test_numbers)

    # Display results
    print("Mathematical Operations Results:")
    print(f"  Factorials: {[f for f in results['factorials'] if f is not None]}")
    print(f"  Prime numbers: {results['primes']}")
    print(f"  Even numbers: {results['evens']}")
    print(f"  Odd numbers: {results['odds']}")

    # Additional validation
    print(f"  Count of numbers processed: {len(test_numbers)}")

# ===== END OF STUDENT WORK =====

if __name__ == "__main__":
    main()
