def add(a, b):
    """Add two numbers"""
    return a + b

def subtract(a, b):
    """Subtract two numbers"""
    return a - b

def multiply(a, b):
    """Multiply two numbers"""
    return a * b

def calculate_total(items):
    """Calculate total of items"""
    total = 0
    for item in items:
        total += add(item, 0)  # Using add function
    return total

if __name__ == "__main__":
    numbers = [1, 2, 3, 4, 5]
    total = calculate_total(numbers)
    print(f"Total: {total}")
