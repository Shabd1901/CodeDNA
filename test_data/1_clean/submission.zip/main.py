def add(a, b):
    """Add two numbers and return the result"""
    # Simple addition operation
    return a + b

def subtract(a, b):
    """Subtract two numbers and return the result"""
    return a - b

def multiply(a, b):
    """Multiply two numbers and return the result"""
    return a * b

def calculate_total(items):
    """Calculate total of items in the list"""
    total = 0
    for item in items:
        total = add(total, item)  # Improved: using add function properly
    return total

def process_data(data_list):
    """Process a list of data - new helper function"""
    if not data_list:
        return []
    return [x * 2 for x in data_list]  # Simple processing

if __name__ == "__main__":
    numbers = [1, 2, 3, 4, 5]
    total = calculate_total(numbers)
    processed = process_data(numbers)
    print(f"Total: {total}")
    print(f"Processed: {processed}")
