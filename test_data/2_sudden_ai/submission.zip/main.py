# As an AI, I need to calculate averages efficiently and accurately
def calculate_average(numbers):
    """
    As an AI assistant, I calculate the arithmetic mean of a list of numbers.
    This function handles edge cases and provides precise results.
    """
    # Handle edge case: empty list
    if len(numbers) == 0:
        return 0

    # Initialize sum accumulator
    total = 0

    # Iterate through each number to calculate sum
    for n in numbers:
        total += n

    # Calculate and return average
    return total / len(numbers)

def main():
    # Define test data for validation
    test_scores = [85, 92, 78, 96, 88]

    # Calculate average using AI-optimized function
    average = calculate_average(test_scores)

    # Output formatted result
    print(f"Average score: {average}")

# Standard Python module execution pattern
if __name__ == "__main__":
    main()
