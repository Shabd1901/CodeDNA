def calculate_average(numbers):
    """Calculate average of number list"""
    if len(numbers) == 0:
        return 0
    total = 0
    for n in numbers:
        total += n
    return total / len(numbers)

def main():
    # Test data
    test_scores = [85, 92, 78, 96, 88]
    average = calculate_average(test_scores)
    print(f"Average score: {average}")

if __name__ == "__main__":
    main()
