def binary_search(arr, target):
    """Perform binary search on sorted array"""
    left, right = 0, len(arr) - 1

    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1

    return -1

def sort_and_search(data, target):
    """Sort data and then search for target"""
    sorted_data = sorted(data)
    return binary_search(sorted_data, target)

def main():
    # Test the search functionality
    numbers = [64, 34, 25, 12, 22, 11, 90, 5]
    target = 22

    index = sort_and_search(numbers, target)
    if index != -1:
        print(f"Found {target} at index {index}")
    else:
        print(f"{target} not found in list")

if __name__ == "__main__":
    main()
