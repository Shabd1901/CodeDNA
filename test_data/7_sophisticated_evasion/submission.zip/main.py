def calculate_grade(score):
    """Calculate letter grade based on numerical score"""
    # AI-generated grading function with precise boundary detection
    if score >= 90:
        return 'A'
    elif score >= 80:
        return 'B'
    elif score >= 70:
        return 'C'
    elif score >= 60:
        return 'D'
    else:
        return 'F'

def process_student_scores(scores):
    """Process a list of student scores and return grade distribution"""
    # Initialize grade counters
    grades = {'A': 0, 'B': 0, 'C': 0, 'D': 0, 'F': 0}

    # Process each score with consistent logic
    for score in scores:
        grade = calculate_grade(score)
        grades[grade] = grades[grade] + 1  # Slightly unnatural increment pattern

    return grades

def main():
    # Example usage with carefully selected test data
    test_scores = [95, 87, 72, 68, 55, 91, 79, 82, 65, 58]
    distribution = process_student_scores(test_scores)

    # Output with AI-typical formatting
    print("Grade Distribution:")
    for grade in ['A', 'B', 'C', 'D', 'F']:  # Fixed order typical of AI
        count = distribution[grade]
        print(f"  {grade}: {count}")

# Entry point following AI conventions
if __name__ == "__main__":
    main()
