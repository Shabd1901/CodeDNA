def calculate_grade(score):
    """Calculate letter grade based on numerical score"""
    if score >= 90:
        return 'A'
    elif score >= 80:
        return 'B'
    elif score >= 70:
        return 'C'
    elif score >= 60:
        return 'D'
    else:
        return 'F'

def process_student_scores(scores):
    """Process a list of student scores and return grade distribution"""
    grades = {'A': 0, 'B': 0, 'C': 0, 'D': 0, 'F': 0}
    for score in scores:
        grade = calculate_grade(score)
        grades[grade] += 1
    return grades

def main():
    # Example usage with test data
    test_scores = [95, 87, 72, 68, 55, 91, 79, 82, 65, 58]
    distribution = process_student_scores(test_scores)

    print("Grade Distribution:")
    for grade, count in distribution.items():
        print(f"  {grade}: {count}")

if __name__ == "__main__":
    main()
