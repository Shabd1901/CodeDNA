/**
 * Calculate nth Fibonacci number using iterative approach
 * @param {number} n - Position in Fibonacci sequence
 * @returns {number} The nth Fibonacci number
 */
function fibonacci(n) {
    if (n <= 1) {
        return n;
    }

    let a = 0;
    let b = 1;
    for (let i = 2; i <= n; i++) {
        const temp = a + b;
        a = b;
        b = temp;
    }
    return b;
}

/**
 * Generate Fibonacci series up to count elements
 * @param {number} count - Number of elements to generate
 * @returns {number[]} Array containing Fibonacci series
 */
function fibonacciSeries(count) {
    const series = [];
    for (let i = 0; i < count; i++) {
        series.push(fibonacci(i));
    }
    return series;
}

// Main execution function
function main() {
    // Generate first 10 Fibonacci numbers
    const fibSeries = fibonacciSeries(10);
    console.log(`Fibonacci series: ${fibSeries}`);

    // Calculate specific values
    [0, 1, 5, 10].forEach(i => {
        console.log(`Fibonacci(${i}) = ${fibonacci(i)}`);
    });
}

// Run if executed directly
if (require.main === module) {
    main();
}
