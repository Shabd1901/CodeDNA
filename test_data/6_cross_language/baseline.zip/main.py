def fibonacci(n):
    """Calculate nth Fibonacci number using iterative approach"""
    if n <= 1:
        return n

    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

def fibonacci_series(count):
    """Generate Fibonacci series up to count elements"""
    series = []
    for i in range(count):
        series.append(fibonacci(i))
    return series

def main():
    # Generate first 10 Fibonacci numbers
    fib_series = fibonacci_series(10)
    print(f"Fibonacci series: {fib_series}")

    # Calculate specific values
    for i in [0, 1, 5, 10]:
        print(f"Fibonacci({i}) = {fibonacci(i)}")

if __name__ == "__main__":
    main()
